# IART
Otimização na Organização de um Jantar

```

g++ -g -Wall -pthread *.cpp -o main
./main ../people.txt ../tables.txt 0.6 0.02 0 5 6  20 5 10 Logarithmic 5

```
