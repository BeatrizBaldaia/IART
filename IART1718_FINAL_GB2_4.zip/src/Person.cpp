/*
 * Person.cpp
 *
 *  Created on: 27/03/2018
 *      Author: anabela
 */

#include "Person.h"

Person::Person() {
	this->age = 0;
	this->group = 0;
	this->religion = Atheism;
	this->job = Science;
}